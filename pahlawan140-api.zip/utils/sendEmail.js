const nodeMailer = require("nodemailer")
const hbs = require('nodemailer-express-handlebars');
const path = require('path')

const sendEmail = async (options) => {
    const transporter = nodeMailer.createTransport({
        service: "Gmail",
        host: "smtp.gmail.com",
        port: 465,
        secure: true,
        auth: {
          user: "pahlawan140.bps@gmail.com",
          pass: "bexfcuoxskzllxnx",
        },
    });
    const handlebarOptions = {
        viewEngine: {
            partialsDir: path.resolve('./views/'),
            defaultLayout: false,
        },
        viewPath: path.resolve('./views/'),
    };
    transporter.use('compile', hbs(handlebarOptions))
    const mailOptions = {
        from: options.from,
        to: options.to,
        subject: options.subject,
        template: options.template,
        context: {
            nama: options.nama,
            link: 'http://localhost:5173/konfirmasi?emailToken='+options.message,
            data: options.data,
        },
    };


    await transporter.sendMail(mailOptions);
};

module.exports = sendEmail;
